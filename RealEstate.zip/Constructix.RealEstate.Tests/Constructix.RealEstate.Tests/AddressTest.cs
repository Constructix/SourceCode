using NUnit.Framework;

namespace Constructix.RealEstate.Tests
{
    [TestFixture]
    public class AddressTest
    {

        [Test]
        public void NewAddress()
        {
            var newAddress = new Address();
            Assert.That(newAddress != null);
        }

        [Test]
        public void AddressSuburbIsNotNull()
        {
            string expectedSuburb = "Karalee";
            var newAddress = new Address {Suburb = "Karalee"};
            Assert.That(newAddress.Suburb.Equals(expectedSuburb));
        }

        [Test]
        public void StateSuburbIsNotNull()
        {
            string state = "qld";
            var newAddress = new Address {State = "qld"};
            Assert.That(newAddress.State.Equals(state));
        }

        [Test]
        public void PostCodeSuburbIsNotNull()
        {
            string expectedPostCode = "4306";
            var newAddress = new Address {Postcode = "4306"};
            Assert.That(newAddress.Postcode.Equals(expectedPostCode));
        }

        [Test]
        public void SuburbToRealEstateComSearchCriteriaString()
        {
            var address = new Address {Suburb = "brighton", Postcode = "4017", State = "qld"};
            var result = address.ToRealEstateSearchString();
            Assert.That(result.Equals("brighton%2c+qld+4017")); 
        }
        
    }
}