﻿namespace FF.Contracts.Dto
{
    public class User
    {

    }
}
