﻿namespace FF.Data.Models
{
    public class ModelBase
    {
        public bool IsActive { get; set; }
    }
}
