﻿namespace RepositoryUnitOfWorkDemo
{
    public class Employee : Person
    {
        
    }
}