using NUnit.Framework;

namespace Constructix.RealEstate.Tests
{
    [TestFixture]
    public class SearchCriteriaTest
    {
        [Test]
        public void InstanceCreated()
        {
            SearchCriteria criteria = new SearchCriteria();
            Assert.That(criteria != null);
        }

        [Test]
        public void AddressAddedToSearchCriteriaTest()
        {
            SearchCriteria criteria = new SearchCriteria
            {
                Address = new Address {Postcode = "4306", State = "qld", Suburb = "Karalee"}
            };
            Assert.That(criteria.Address != null);
        }

        [Test]
        public void SearchCriteriaToRealEstateString()
        {
            SearchCriteria criteria = new SearchCriteria
            {
                Address = new Address { Postcode = "4017", State = "qld", Suburb = "brighton" }
            };
            var result = criteria.ToRealEstateComSearchString();
            Assert.That(result.Equals("http://www.realestate.com.au/buy/property-house-with-3-bedrooms-in-brighton%2c+qld+4017/list-1?numParkingSpaces=1&numBaths=1&maxBeds=3&includeSurrounding=false&persistIncludeSurrounding=true&misc=ex-under-contract&activeSort=price-asc&source=location-search"));
        }
    }
}