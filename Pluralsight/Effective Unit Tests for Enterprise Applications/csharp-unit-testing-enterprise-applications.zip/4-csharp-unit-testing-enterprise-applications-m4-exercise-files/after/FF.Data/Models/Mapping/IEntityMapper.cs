﻿using AutoMapper;

namespace FF.Data.Models.Mapping
{
    public interface IEntityMapper
    {
        IMapper GetEntityMapper();
    }
}
