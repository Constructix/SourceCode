﻿using System.Runtime.InteropServices.ComTypes;
using Constructix.Core.Contracts.Data;

namespace Constructix.Core.Common.Data
{
    
    public interface IDataRepositoryFactory
    {
        T GetDataRepository<T>() where T : IDataRepository;
    }

    
}