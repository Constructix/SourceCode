﻿namespace FF.Data
{
    public class InfoLoggerDal
    {
        public int SaveIpAddress(string ipAddress, string user)
        {
            return 1;
        }
    }
}
