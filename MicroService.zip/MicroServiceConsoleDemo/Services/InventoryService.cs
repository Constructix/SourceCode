﻿namespace ConsoleApp1
{
    public class InventoryService
    {
        
    }
}