﻿namespace FF.Contracts.Service
{
    public interface IFruitFinderService
    {

    }
}
