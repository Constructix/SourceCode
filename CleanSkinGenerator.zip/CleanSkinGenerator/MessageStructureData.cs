﻿using System.Collections.Generic;

namespace CleanSkinGenerator
{
    public class MessageStructureData
    {
        public List<Header> Headers { get; set; }
    }
}