using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using NUnit.Framework;
using System.Text.RegularExpressions;

namespace Constructix.RealEstate.Tests
{
    [TestFixture]
    public class ListingExtractorTests
    {
        [Test]
        public void ExtractListingNoException()
        {
            ListingsExtractor extractor = new ListingsExtractor();
            Assert.That(extractor != null);

        }

        [Test]
        public void ExtractListingFromSpecifiedHTMLDocument()
        {

           



            const string dataFile = @"D:\Files\1.html";

            List<string> totalValues = new List<string>();
            string[] htmlFiles = Directory.GetFiles(@"D:\Files", "*.html");
            foreach (string htmlFile in htmlFiles)
            {
                string htmlData = File.OpenText(htmlFile).ReadToEnd();
                ListingsExtractor extractor = new ListingsExtractor();
                List<string> listings = extractor.Extract(htmlData);
                totalValues.AddRange(listings);
            }
            Console.WriteLine("Suburb Price");
            totalValues.ForEach(Console.WriteLine);
          
        }
    }
}