using System;
using System.Net;

namespace Constructix.RealEstate.Tests
{
    public class Downloader 
    {
        public static string Download(string htmlLocation)
        {
            WebClient client = new WebClient();
            var proxy = new WebProxy("ittdarray.prod.atonet.gov.au");
            proxy.Credentials = new NetworkCredential(@"ucihf", "Brisbane01", "atonet");
            client.Proxy = proxy;
            try
            {
                return client.DownloadString(htmlLocation);
            }
            catch (WebException webEx)
            {
                throw;
            }
            catch (Exception)
            {
                
                throw;
            }
            
        }
    }
}