﻿namespace FF.Contracts.Service
{
    public interface IFruitReviewService
    {
       
    }
}
