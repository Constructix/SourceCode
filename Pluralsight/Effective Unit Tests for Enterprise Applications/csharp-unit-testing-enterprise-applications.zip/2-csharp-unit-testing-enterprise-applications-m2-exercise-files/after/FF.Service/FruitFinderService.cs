﻿using FF.Contracts.Service;

namespace FF.Service
{
    public class FruitFinderService : BaseService, IFruitFinderService
    {
        public FruitFinderService() : base()
        {
            
        }


    }
}
