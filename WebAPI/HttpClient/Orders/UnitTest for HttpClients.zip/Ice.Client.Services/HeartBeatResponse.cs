﻿namespace Ice.Client.Services
{
    public class HeartBeatResponse
    {
        public bool IsAlive { get; set; }
    }
}