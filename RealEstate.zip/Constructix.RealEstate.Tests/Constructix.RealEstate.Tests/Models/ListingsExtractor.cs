using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using HtmlAgilityPack;

namespace Constructix.RealEstate.Tests
{
    public class ListingsExtractor
    {
        public List<string> Extract(string htmlData)
        {

            List<string> values = new List<string>();
            HtmlNode.ElementsFlags.Remove("form");
            HtmlDocument document = new HtmlDocument();
            document.LoadHtml(htmlData);

            HtmlNode searchResultsNode = document.GetElementbyId("searchResultsTbl");
            if (searchResultsNode != null)
            {
                HtmlNodeCollection propertyListingCollection = searchResultsNode.SelectNodes("article[contains(@class,'resultBody')]");

                foreach (HtmlNode htmlNode in propertyListingCollection)
                {

                    HtmlNode priceNode =htmlNode.SelectSingleNode("aside[contains(@class,'listing-content')]/div[contains(@class,'listingInfo')]/div[contains(@class,'propertyStats')]/p|div[contains(@class,'listingInfo')]/div[contains(@class,'propertyStats')]/p|div[contains(@class,'listing-content')]/div[contains(@class,'listingInfo')]/div[contains(@class,'propertyStats')]/p");
                    if (priceNode != null)
                    {
                        Regex regex = new Regex(@"\$?\d+(,\d{3})*(\.\d*)?");
                            Match m = regex.Match(priceNode.InnerText);
                            if (m.Success)
                                values.Add(m.Value);
                    }
                }
            }
            return values;
        }
    }
}