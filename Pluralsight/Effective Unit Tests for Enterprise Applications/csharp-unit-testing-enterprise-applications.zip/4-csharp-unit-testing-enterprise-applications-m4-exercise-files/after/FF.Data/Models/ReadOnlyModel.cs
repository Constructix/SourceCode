﻿namespace FF.Data.Models
{
    public class ReadOnlyModel : ModelBase
    {
    }
}
