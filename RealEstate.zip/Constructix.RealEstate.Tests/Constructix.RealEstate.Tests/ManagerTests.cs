using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using NUnit.Framework;
using OfficeOpenXml;
using OfficeOpenXml.FormulaParsing;
using OfficeOpenXml.Style;

namespace Constructix.RealEstate.Tests
{
    [TestFixture]
    public class ExcelTests
    {
        [Test]
        public void CreateExcelFile()
        {
            using (ExcelPackage package = new ExcelPackage(new FileInfo(@"D:\Files\RealEstate\analysis.xlsx")))
            {
                ExcelWorksheet workSheet = null;
                if (!package.Workbook.Worksheets.Any(x=>x.Name.Equals("Analysis")))
                     workSheet = package.Workbook.Worksheets.Add("Analysis");


                int index;
                string[] files = Directory.GetFiles(@"D:\Files\RealEstate", "*.txt");

                foreach (var file in files)
                {
                   var fileInfo = new FileInfo(file);
                    workSheet = package.Workbook.Worksheets.Add(fileInfo.Name);

                    index = 1;
                    using(StreamReader reader = File.OpenText(file))
                    {
                        while (reader.Peek() != -1)
                        {
                            int newValue;
                            string newValueAsString = reader.ReadLine().Replace("$", "").Replace(",","");
                            int.TryParse(newValueAsString, out  newValue);
                            workSheet.Cells[index, 1].Value = newValue;
                            index++;
                        }
                    }
                }

                index = 1;
                for (int i = 2; i < package.Workbook.Worksheets.Count; i++)
                {
                    package.Workbook.Worksheets["Analysis"].Cells[index, 1].Value = package.Workbook.Worksheets[i].Name;
                    package.Workbook.Worksheets["Analysis"].Cells[index, 2].Formula ="MIN('"+ package.Workbook.Worksheets[i].Name +"'!A:A)";
                    package.Workbook.Worksheets["Analysis"].Cells[index, 3].Formula = "MEDIAN('" + package.Workbook.Worksheets[i].Name + "'!A:A)";
                    package.Workbook.Worksheets["Analysis"].Cells[index, 4].Formula = "MAX('" + package.Workbook.Worksheets[i].Name + "'!A:A)";


                    package.Workbook.Worksheets["Analysis"].Cells[index, 5].Formula = string.Format("(C{0} - B{0})/C{0}", index);
                    package.Workbook.Worksheets["Analysis"].Cells[index, 6].Formula = string.Format("(D{0} - C{0})/D{0}", index);

                    package.Workbook.Worksheets["Analysis"].Cells[index, 7].Formula = string.Format("(F{0} - E{0})", index);


                    index++;
                }


                package.Save();
            }

        }
    }


    [TestFixture]
    public class ManagerTests
    {
        [Test]
        public void ManagerInstanceCreated()
        {
            RealEstateManager manager = new RealEstateManager();
            Assert.That(manager != null);
        }

        [Test]
        public void GetListingHtmlDocumentForSuburbNoException()
        {
            


            List<SearchCriteria> criterias = new List<SearchCriteria>();
            criterias.Add(new SearchCriteria { Address = new Address { Postcode = "4301", Suburb = "Redbank Plains", State = "qld"} });
            criterias.Add(new SearchCriteria { Address = new Address { Postcode = "4305", Suburb = "Raceview", State = "qld" } });
            criterias.Add(new SearchCriteria { Address = new Address { Postcode = "4305", Suburb = "Eastern Heights", State = "qld" } });
            criterias.Add(new SearchCriteria { Address = new Address { Postcode = "4305", Suburb = "Churchill", State = "qld" } });
            criterias.Add(new SearchCriteria { Address = new Address { Postcode = "4305", Suburb = "One Mile", State = "qld" } });
            criterias.Add(new SearchCriteria { Address = new Address { Postcode = "4305", Suburb = "Leichhardt", State = "qld" } });
            criterias.Add(new SearchCriteria { Address = new Address { Postcode = "4305", Suburb = "West Ipswich", State = "qld" } });
            criterias.Add(new SearchCriteria { Address = new Address { Postcode = "4305", Suburb = "Yamanto", State = "qld" } });
            criterias.Add(new SearchCriteria { Address = new Address { Postcode = "4306", Suburb = "Ripley", State = "qld" } });

            foreach (SearchCriteria currentSearchCriteria in criterias)
            {
                RealEstateManager manager = new RealEstateManager();
                StringBuilder result = new StringBuilder();
                foreach (var price in manager.GetPrices(currentSearchCriteria))
                {
                    result.AppendLine(price);
                }
                File.WriteAllText(string.Format(@"D:\Files\RealEstate\{0}.txt", currentSearchCriteria.Address.Suburb), result.ToString());
            }
        }
    }
}