﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;
using System.Xml.XPath;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OfficeOpenXml;

namespace TFNDMappingChecking
{

    [TestClass]
    public class RequestTFNDTest
    {
        private const string InputRequestFile = @"D:\Temp\2010 Request.xml";
        private XDocument document;

        [TestInitialize]
        public void TestInitialise()
        {
            document = XDocument.Load(InputRequestFile);
        }

        [TestMethod]
        public void DocumentInstanceNotNull()
        {

            Assert.IsNotNull(document);
        }

        [TestMethod]
        public void Extract_RP_TelephoneNumberNotNull()
        {
            //XNamespace p = "http://sbr.gov.au/icls/py/pyde/pyde.02.00.data";
            var businessDocumentText =
                document.Descendants()
                    .FirstOrDefault(x => x.Name.LocalName.Equals("BusinessDocument.Instance.Text"));


            XDocument testDoc = XDocument.Parse(businessDocumentText.Descendants().FirstOrDefault().ToString());
            Assert.IsNotNull(testDoc);
            var result = GetNameSpacesFromXDocument(testDoc);
            Assert.IsNotNull(businessDocumentText);
            //string elementToLookFor = "pyde.02.00:AddressDetails.Usage.Code";
            //string namespaceToLookFor = elementToLookFor.Substring(0, elementToLookFor.IndexOf(":"));
            //XNamespace p = result[namespaceToLookFor];
            XName addressDetailsUsageCode = GetName("pyde.02.00:AddressDetails.Usage.Code", result);
            var addressDetails =
                businessDocumentText.Descendants()
                    .FirstOrDefault(x =>x.Name.Equals(addressDetailsUsageCode) && x.Value.Equals("BUS") &&
                            (x.Attributes().Any(y => y.Name.LocalName.Equals("contextRef") && y.Value.Equals("RP"))));
            Assert.IsNotNull(addressDetails);
            if (addressDetails != null)
            {
                var parentAddressDetails = addressDetails.Parent;
                var locality =parentAddressDetails.Descendants().FirstOrDefault(x => x.Name.Equals(GetName("pyde.02.00:AddressDetails.LocalityName.Text", result))).Value;

                Assert.AreEqual(locality, "sydney");
                Console.WriteLine(locality);

                XName stateTerritoryXName = GetName("pyde.02.00:AddressDetails.StateOrTerritory.Code", result);
                var state = parentAddressDetails.Descendants().FirstOrDefault(x => x.Name.Equals(stateTerritoryXName)).Value;

                Console.WriteLine(state);
                Assert.AreEqual(state, "NSW");


            }
        }

        private static XName GetName(string dataElementName, Dictionary<string, XNamespace> nameSpaces)
        {
            string elementToLookFor = dataElementName;
            int indexPos = elementToLookFor.IndexOf(":");
            string namespaceToLookFor = elementToLookFor.Substring(0, elementToLookFor.IndexOf(":"));

            XNamespace ns = nameSpaces[namespaceToLookFor];
            XName newName  = ns + dataElementName.Substring(indexPos + 1);
            return newName;
        }


    private static Dictionary<string, XNamespace> GetNameSpacesFromXDocument(XDocument testDoc)
        {
            var result = testDoc.Root.Attributes()
                .Where(a => a.IsNamespaceDeclaration)
                .GroupBy(a => a.Name.Namespace == XNamespace.None ? string.Empty : a.Name.LocalName,
                    a => XNamespace.Get(a.Value)).ToDictionary(g => g.Key, g => g.First());
            return result;
        }
    }



    [TestClass]
    public class InputExcelMappingFileTest
    {
        private const string ExcelMappingFile = @"D:\Temp\TFND.0003 2016 AP361 Mapping Rules ICP.xlsx";

        private ExcelPackage _excelPackage;


        [TestMethod]
        public void OpenningExcelMappingFileNoException()
        {
            using (_excelPackage = new ExcelPackage(new FileInfo(ExcelMappingFile)))
            {
                Assert.IsNotNull(_excelPackage);

            }
        }
    }
}
