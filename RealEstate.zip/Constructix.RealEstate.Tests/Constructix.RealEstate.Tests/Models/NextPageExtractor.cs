using System;
using HtmlAgilityPack;
using NUnit.Framework;

namespace Constructix.RealEstate.Tests
{
    public class NextPageExtractor
    {
        public  static string GetNextPage(string htmlString)
        {
            string nextPageAddress = string.Empty;
            HtmlNode.ElementsFlags.Remove("form");
            HtmlDocument document = new HtmlDocument();
            document.LoadHtml(htmlString);
            HtmlNode nextPageNode = document.DocumentNode.SelectSingleNode("html/head/link[@rel='next']");
            if (nextPageNode != null)
            {
                nextPageAddress = nextPageNode.Attributes["href"].Value;
                Console.WriteLine(nextPageAddress);
             
            }

            return nextPageAddress;
        }
    }
}