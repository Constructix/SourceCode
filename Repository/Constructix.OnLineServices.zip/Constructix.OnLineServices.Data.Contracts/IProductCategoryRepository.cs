﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Constructix.Core.Contracts.Data;

namespace Constructix.OnLineServices.Data.Contracts
{
    public interface IProductCategoryRepository: IDataRepository<ProductCategory>
    {

    }
}
