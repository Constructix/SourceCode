using System.Text;

namespace Constructix.RealEstate.Tests
{
    public class SearchCriteria
    {
        public Address Address { get; set; }

        public string ToRealEstateComSearchString()
        {
            StringBuilder builder = new StringBuilder();

            builder.Append("http://www.realestate.com.au/buy/property-house-with-3-bedrooms-in-");
            builder.Append(this.Address.ToRealEstateSearchString());
            builder.Append("/list-1?numParkingSpaces=1&numBaths=1&maxBeds=3&includeSurrounding=false&persistIncludeSurrounding=true&misc=ex-under-contract&activeSort=price-asc&source=location-search");

            return builder.ToString();
        }
    }
}