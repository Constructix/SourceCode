﻿using System;
using System.Runtime.Remoting;

namespace ObserverPattern
{
    public class UserInterface : IObserver
    {
        public void AfterDoSomethingWith(ISubject subject, string data)
        {
            Console.WriteLine($"Hey user, look at {data.ToUpper()}");
        }
        public void AfterDoMore(ISubject sender, string completeData, string appendData)
        {
       
        }
    }
}