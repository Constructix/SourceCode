namespace Constructix.RealEstate.Tests
{
    public class Address
    {
        public string Suburb { get; set; }
        public string State { get; set; }
        public string Postcode { get; set; }

        public string ToRealEstateSearchString()
        {
            return string.Format("{0}%2c+{1}+{2}", this.Suburb, this.State, this.Postcode);
        }
    }
}