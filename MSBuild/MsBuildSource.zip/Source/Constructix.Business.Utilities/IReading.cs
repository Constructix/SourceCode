using System;

namespace Constructix.Business.Utilities
{
	public interface IReading 
	{
		void Total();
	}
}