﻿using System.ComponentModel.Composition;
using Constructix.Core.Common;
using Constructix.Core.Common.Data;
using Constructix.Core.Contracts.Data;

namespace Constructix.OnLineServices.Data
{
    [Export(typeof(IDataRepositoryFactory))]
    [PartCreationPolicy(CreationPolicy.NonShared)]
    public class DataRepositoryFactory : IDataRepositoryFactory
    {
        public T GetDataRepository<T>() where T : IDataRepository
        {
            
            return  ObjectBase.Container.GetExportedValue<T>();
        }
    }
}