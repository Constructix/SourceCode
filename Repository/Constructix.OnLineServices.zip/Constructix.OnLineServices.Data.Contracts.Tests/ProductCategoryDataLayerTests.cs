﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.ComponentModel.Composition.Hosting;
using System.Linq;
using System.Security.Permissions;
using Constructix.Core.Common;
using Constructix.Core.Common.Data;
using Moq;
using NUnit.Framework;

namespace Constructix.OnLineServices.Data.Contracts.Tests
{
    public class ProductCategoryDataLayerTests
    {
        [SetUp]
        public void Initialise()
        {
            RepositoryTestClass testClass = new RepositoryTestClass();
        }


        [Test]
        public void ProductCategoryFactoryRepositoryTest()
        {
            RepositoryFactoryTestClass RepositoryFactory = new RepositoryFactoryTestClass();

            IEnumerable<ProductCategory> categories = RepositoryFactory.GetProductCategories();

            Assert.That(categories.Any());
        }


        [Test]
        public void ProductCategoryFactoryRepositoryMockTest()
        {
            IList<ProductCategory> productCategories = new List<ProductCategory>
           {
               new ProductCategory { Id=1, Created = DateTime.Now, Name = "Decking"},
               new ProductCategory { Id=2,Created = DateTime.Now, Name="Fencing" },
               new ProductCategory { Id=2,Created = DateTime.Now, Name="Hardwood" }
           };


            Mock<IDataRepositoryFactory> mockDataRepository = new Mock<IDataRepositoryFactory>();
            mockDataRepository.Setup(obj => obj.GetDataRepository<IProductCategoryRepository>().Get())
                .Returns(productCategories);

            RepositoryFactoryTestClass testClass = new RepositoryFactoryTestClass(mockDataRepository.Object);

            IEnumerable<ProductCategory> categories = testClass.GetProductCategories();


            Console.WriteLine("Product Categories are as follows:");
            foreach (ProductCategory currentProductCategory in categories)
            {
                Console.WriteLine(currentProductCategory.Name);
            }
        }

        [Test]
        public void TestRepositoryUsage()
        {
            RepositoryTestClass repositoryTest = new RepositoryTestClass();


            var productCategories = repositoryTest.GetProductCategories();

            foreach (ProductCategory productCategory in productCategories)
            {
                Console.WriteLine(productCategory.Name);
            }
        }

        [Test]
        public void TestRepositoryMocking()
        {
           IList<ProductCategory> productCategories = new List<ProductCategory>
           {
               new ProductCategory { Id=1, Created = DateTime.Now, Name = "Decking"},
               new ProductCategory { Id=2,Created = DateTime.Now, Name="Fencing" },
               new ProductCategory { Id=2,Created = DateTime.Now, Name="Hardwood" }
           };

            Mock<IProductCategoryRepository> mockProductCategoryRepository = new Mock<IProductCategoryRepository>();
            mockProductCategoryRepository.Setup(x => x.Get()).Returns(productCategories);

            RepositoryTestClass repositoryTest = new RepositoryTestClass(mockProductCategoryRepository.Object);


            foreach (ProductCategory currentProductCategory in repositoryTest.GetProductCategories())
            {
                Console.WriteLine(currentProductCategory.Name);
            }

            Assert.That(repositoryTest.GetProductCategories().Any());

        }
    }


    public class MEFLoader
    {
        public static CompositionContainer Init()
        {
            AggregateCatalog catalog  = new AggregateCatalog();
            catalog.Catalogs.Add(new AssemblyCatalog(typeof(ProductCategoryRepository).Assembly));
            CompositionContainer container = new CompositionContainer(catalog);
            return container;
        }
    }


    public class RepositoryTestClass
    {

        public RepositoryTestClass()
        {
            var container = MEFLoader.Init();
            container.SatisfyImportsOnce(this);
        }


        public RepositoryTestClass(IProductCategoryRepository repository)
        {
            _productCategoryRepository = repository;
        }

        #region Properties
        [Import]
        IProductCategoryRepository _productCategoryRepository;
        #endregion

        public IEnumerable<ProductCategory> GetProductCategories()
        {
            return _productCategoryRepository.Get();
        }
    }


    public class RepositoryFactoryTestClass
    {

        [Import]
        IDataRepositoryFactory _dataRepositoryFactory;

        public RepositoryFactoryTestClass()
        {
            ObjectBase.Container = MEFLoader.Init();
            ObjectBase.Container.SatisfyImportsOnce(this);

        }

        public RepositoryFactoryTestClass(IDataRepositoryFactory dataRepositoryFactory)
        {
            _dataRepositoryFactory = dataRepositoryFactory;
        }


        public IEnumerable<ProductCategory> GetProductCategories()
        {
            IProductCategoryRepository productCategoryRepository =
                _dataRepositoryFactory.GetDataRepository<IProductCategoryRepository>();


            return productCategoryRepository.Get();
        }
    }
}