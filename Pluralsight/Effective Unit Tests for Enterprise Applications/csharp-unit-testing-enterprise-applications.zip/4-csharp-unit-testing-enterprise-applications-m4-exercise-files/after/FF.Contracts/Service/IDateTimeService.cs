﻿using System;

namespace FF.Contracts.Service
{
    public interface IDateTimeService
    {
        DateTime UtcNow();
    }
}
