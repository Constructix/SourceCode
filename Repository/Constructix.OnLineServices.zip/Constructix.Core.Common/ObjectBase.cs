﻿using System.ComponentModel;
using System.ComponentModel.Composition.Hosting;
using System.Dynamic;

namespace Constructix.Core.Common
{
    public class ObjectBase
    {
        public static CompositionContainer Container { get; set; }
        
    }

    

}