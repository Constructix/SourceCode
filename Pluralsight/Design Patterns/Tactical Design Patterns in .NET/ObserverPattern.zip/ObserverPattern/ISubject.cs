﻿namespace ObserverPattern
{
    public interface ISubject
    {
        void Attach(IObserver observer);
        void Detach(IObserver Observer);
        void AfterDoSomethingWith(string data);
        void AfterDoMore(string completeData, string appendData);
    }
}