using System.Collections.Generic;
using NUnit.Framework;

namespace Constructix.RealEstate.Tests
{
    [TestFixture]
    public class DownloadTest
    {
        [Test]
        public void DownloadInstance()
        {

            SearchCriteria criteria = new SearchCriteria
            {
                Address = new Address { Postcode = "4017", State = "qld", Suburb = "brighton" }
            };
            var htmlData = Downloader.Download(criteria.ToRealEstateComSearchString());

            Assert.That(!string.IsNullOrEmpty(htmlData));
        }
    }


    public class RealEstateManager
    {

        public List<string> GetPrices(SearchCriteria criteria)
        {
            List<string> htmlDocuments = GetHtmlPages(criteria);
            List<string> prices = GetPricesFromHtmlDocuments(htmlDocuments);
            return prices;
        }


        public List<string> GetHtmlPages(SearchCriteria criteria)
        {
            List<string> htmlDocs = new List<string>();
            string pageAddress = criteria.ToRealEstateComSearchString();

            string htmlData = Downloader.Download(pageAddress);
            while (!string.IsNullOrEmpty(htmlData))
            {
                htmlDocs.Add(htmlData);
                pageAddress = NextPageExtractor.GetNextPage(htmlData);
                if (string.IsNullOrEmpty(pageAddress))
                    break;
                htmlData = Downloader.Download(pageAddress);
            }


            return htmlDocs;

        }

        public List<string> GetPricesFromHtmlDocuments(List<string> htmlDocuments)
        {
            List<string> prices = new List<string>();

            foreach (string currentHtmlDocument in htmlDocuments)
            {
                ListingsExtractor extractor = new ListingsExtractor();
                List<string> listings = extractor.Extract(currentHtmlDocument);
                prices.AddRange(listings);
            }
            return prices;
        }
    }
}