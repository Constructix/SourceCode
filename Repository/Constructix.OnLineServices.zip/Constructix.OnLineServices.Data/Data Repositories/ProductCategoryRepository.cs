﻿using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using Constructix.Core.Common.Data;
using Constructix.OnLineServices.Data.Contracts;

namespace Constructix.OnLineServices.Data
{
    [Export(typeof(IProductCategoryRepository))]
    [PartCreationPolicy(CreationPolicy.NonShared)]
    public class ProductCategoryRepository : DataRepositoryBase<ProductCategory>, IProductCategoryRepository 
    {
        protected override ProductCategory AddEntity(ConstructixContext entityContext, ProductCategory entity)
        {
            return entityContext.ProductCategorySet.Add(entity);
        }

        protected override ProductCategory UpdateEntity(ConstructixContext entityContext, ProductCategory entity)
        {
            return entityContext.ProductCategorySet.FirstOrDefault(x => x.Id == entity.Id);
        }

        protected override IEnumerable<ProductCategory> GetEntities(ConstructixContext entityContext)
        {
            return entityContext.ProductCategorySet;
        }

        protected override ProductCategory GetEntity(ConstructixContext entityContext, int id)
        {
            return entityContext.ProductCategorySet.FirstOrDefault(x => x.Id == id);
        }
    }

    public abstract class DataRepositoryBase<T>: DataRepositoryBase<T, ConstructixContext> where T : class, new()
    {
        
    }
}