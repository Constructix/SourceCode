﻿namespace Ice.Client.Services
{
    public class Jurisdiction
    {
        public string EndpointAddress { get; set; }
    }
}