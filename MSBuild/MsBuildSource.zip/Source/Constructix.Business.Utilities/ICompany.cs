using System;

namespace Constructix.Business.Utilities
{
	public interface ICompany
	{
		void Total();
	}
}