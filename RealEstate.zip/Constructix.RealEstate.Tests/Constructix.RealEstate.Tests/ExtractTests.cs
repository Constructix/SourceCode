using System;
using System.IO;
using System.Net;
using NUnit.Framework;

namespace Constructix.RealEstate.Tests
{
    [TestFixture]
    public class ExtractTests
    {
        [Test]
        public void ExtractNextPage()
        {
            string nextPage  = NextPageExtractor.GetNextPage(File.ReadAllText(@"D:\Files\ba084757-a2aa-4bec-84ca-9687bee9a06c.html"));
            Assert.That(!string.IsNullOrEmpty(nextPage));

        }

        [Test]
        [Ignore("Not needed at this time.")]
        public void DownloadHtmlPageNoException()
        {
            string htmlLocation = "http://www.realestate.com.au/buy/property-house-with-3-bedrooms-in-brighton%2c+qld+4017/list-1?numParkingSpaces=1&numBaths=1&maxBeds=3&includeSurrounding=false&persistIncludeSurrounding=true&misc=ex-under-contract&activeSort=price-asc&source=location-search";

            WebClient client = new WebClient();
            string downloadedData =   client.DownloadString(htmlLocation);


            if (!Directory.Exists(@"D:\Files"))
                Directory.CreateDirectory(@"D:\Files");


            string fileName = string.Format(@"D:\Files\{0}.html", Guid.NewGuid().ToString());
            System.IO.File.WriteAllText(fileName, downloadedData);

            Assert.That(downloadedData != null);
        }
    }
}